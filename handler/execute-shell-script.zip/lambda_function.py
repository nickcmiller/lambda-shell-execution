def lambda_handler(event, context):
    
    #FINDING INSTANCES TO EXECUTE SCRIPT ON
    
    #import boto3 and define ec2 client
    import boto3
    ec2_client=boto3.client("ec2", region_name='us-east-1')
    
    
